#ifndef _DEBUG_MACRO_H
#define _DEBUG_MACRO_H


#define _MAIN_TEST_
#define _PRE_PROCESS_
//#define _BINARY_

//#define _MODULATE_DATA_
#define _REAL_DATA_

//#define _DEBUG_INFO_

//#define _ONLY_ROUGH_
#define _EURO_DIST_
//#define _MAHA_DIST_
//#define _ANGLE_DIST_

#define _MY_MOMENT_


#endif